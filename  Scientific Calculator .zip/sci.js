document.addEventListener('DOMContentLoaded', () => {
  let input = document.getElementById('i');
  let buttons = document.querySelectorAll('.button');
  let string = "";

  buttons.forEach((button) => {
    button.addEventListener('click', () => {
      if (button.textContent === 'AC') {
        string = "";
      } else if (button.textContent === '=') {
        try {
          string = eval(string);
        } catch (error) {
          string = 'Error';
        }
      } else if (button.textContent === 'pi') {
        string += Math.PI;
      } else if (button.textContent === 'e') {
        string += Math.E;
      } else if (button.textContent === 'sqrt') {
        string += 'Math.sqrt(';
      } else if (button.textContent === 'log') {
        string += 'Math.log10(';
      } else if (button.textContent === 'ln') {
        string += 'Math.log(';
      } else if (button.textContent === 'sin') {
        string += 'Math.sin(';
      } else if (button.textContent === 'cos') {
        string += 'Math.cos(';
      } else if (button.textContent === 'tan') {
        string += 'Math.tan(';
      } else if (button.textContent === '!') {
        string += 'factorial(';
      } else {
        string += button.textContent;
      }
      input.value = string;
    });
  });
});

function factorial(num) {
  if (num === 0 || num === 1) {
    return 1;
  }
  for (let i = num - 1; i >= 1; i--) {
    num *= i;
  }
  return num;
}